export enum CategoryType {
  TIENDA = "Tienda / Supermercado",
  DROGUERIA = "Droguería",
  CARNICERIA = "Carnicería",
  TALLER_MOTO = "Taller de Motos",
  TALLER_CARRO = "Taller de Carros",
  TRANSPORTE = "Transporte Comercial",
  PRODUCTOR = "Productor Agrícola",
  ELECTRICISTA = "Electricista",
  REPARACIONES = "Servicios y Reparaciones",
  ESTETICA = "Peluquería y Estética",
  PANADERIA = "Panadería / Cafetería"
}

export interface Business {
  id: string;
  name: string;
  category: CategoryType;
  owner: string;
  phone: string;
  address: string;
  pointsRate: number; // e.g. 1 point per $1,000 COP spent (so a rate of 0.001 or custom rate)
  description?: string;
  featured?: boolean;
}

export interface User {
  code: string;
  name: string;
  phone: string;
  points: number;
  totalEarned: number;
  isAdmin?: boolean;
  active?: boolean;
}

export interface PurchaseReport {
  id: string;
  userCode: string;
  userName: string;
  businessId: string;
  businessName: string;
  amount: number;
  pointsEarned: number;
  date: string;
  receiptNumber?: string;
  notes?: string;
  status: "pending" | "approved" | "rejected";
  rejectionReason?: string;
}

export interface Prize {
  id: string;
  title: string;
  pointsCost: number;
  description: string;
  image?: string;
  stock: number;
}

export interface Redemption {
  id: string;
  userCode: string;
  userName: string;
  prizeId: string;
  prizeTitle: string;
  pointsCost: number;
  date: string;
  status: "pending" | "completed";
}
