import { CategoryType } from "../types";

export interface CategoryMetadata {
  type: CategoryType;
  iconName: string; // Used to choose which lucide-react icon to display
  color: string; // Tailwind class background
  textColor: string; // Tailwind text color
  borderColor: string; // Tailwind border
  desc: string;
}

export const CATEGORIES_METADATA: CategoryMetadata[] = [
  {
    type: CategoryType.TIENDA,
    iconName: "Store",
    color: "bg-amber-50 hover:bg-amber-100",
    textColor: "text-amber-800",
    borderColor: "border-amber-200",
    desc: "Abarrotes, víveres y supermercados del pueblo",
  },
  {
    type: CategoryType.PRODUCTOR,
    iconName: "Sprout",
    color: "bg-emerald-50 hover:bg-emerald-100",
    textColor: "text-emerald-800",
    borderColor: "border-emerald-200",
    desc: "Productores locales directo del campo a tu mesa",
  },
  {
    type: CategoryType.DROGUERIA,
    iconName: "PlusCircle",
    color: "bg-blue-50 hover:bg-blue-100",
    textColor: "text-blue-800",
    borderColor: "border-blue-200",
    desc: "Salud, medicamentos y cuidado familiar",
  },
  {
    type: CategoryType.CARNICERIA,
    iconName: "Beef",
    color: "bg-red-50 hover:bg-red-100",
    textColor: "text-red-800",
    borderColor: "border-red-200",
    desc: "Cortes frescos, pollo, cerdo y pescados",
  },
  {
    type: CategoryType.PANADERIA,
    iconName: "Wheat", // replaces croissant or generic bread
    color: "bg-orange-50 hover:bg-orange-100",
    textColor: "text-orange-850",
    borderColor: "border-orange-200",
    desc: "Cafeterías, pan fresco, repostería y desayunos",
  },
  {
    type: CategoryType.TALLER_MOTO,
    iconName: "Wrench",
    color: "bg-slate-50 hover:bg-slate-100",
    textColor: "text-slate-800",
    borderColor: "border-slate-200",
    desc: "Reparación, repuestos y mantenimiento de motocicletas",
  },
  {
    type: CategoryType.TALLER_CARRO,
    iconName: "Car",
    color: "bg-zinc-50 hover:bg-zinc-100",
    textColor: "text-zinc-800",
    borderColor: "border-zinc-200",
    desc: "Mecánica general, alineaciones y autolavados",
  },
  {
    type: CategoryType.TRANSPORTE,
    iconName: "Truck",
    color: "bg-cyan-50 hover:bg-cyan-100",
    textColor: "text-cyan-800",
    borderColor: "border-cyan-200",
    desc: "Servicio de acarreos, mototaxis y expresos",
  },
  {
    type: CategoryType.ELECTRICISTA,
    iconName: "Zap",
    color: "bg-yellow-50 hover:bg-yellow-105",
    textColor: "text-yellow-800",
    borderColor: "border-yellow-200",
    desc: "Técnicos certificados para tu hogar o negocio",
  },
  {
    type: CategoryType.REPARACIONES,
    iconName: "Hammer",
    color: "bg-stone-50 hover:bg-stone-100",
    textColor: "text-stone-800",
    borderColor: "border-stone-200",
    desc: "Plomería, soldadura, construcción y pintura",
  },
  {
    type: CategoryType.ESTETICA,
    iconName: "Scissors",
    color: "bg-pink-50 hover:bg-pink-100",
    textColor: "text-pink-800",
    borderColor: "border-pink-200",
    desc: "Peluquería, masajes, uñas y cuidado personal",
  }
];
