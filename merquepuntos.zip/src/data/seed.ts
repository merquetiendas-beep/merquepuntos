import { Business, CategoryType, User, Prize } from "../types";

export const SEED_BUSINESSES: Business[] = [
  // Tiendas / Supermercados
  {
    id: "biz-tienda-1",
    name: "Autoservicio El Progreso",
    category: CategoryType.TIENDA,
    owner: "Don Alirio Castro",
    phone: "3124567890",
    address: "Calle Real #4-25, Frente a la Plaza",
    pointsRate: 1, // 1 point per $10,000 COP spent is handled in app logic, but pointsRate acts as a multiplier
    description: "Gran variedad en víveres, rancho, licores y aseo. El mejor servicio del pueblo.",
    featured: true
  },
  {
    id: "biz-tienda-2",
    name: "Tienda La Bendición",
    category: CategoryType.TIENDA,
    owner: "Doña Elena Gómez",
    phone: "3159876543",
    address: "Barrio San Jorge, Carrera 8 #12-10",
    pointsRate: 1,
    description: "La tienda de la esquina con todo lo que necesitas para tu día a día."
  },
  {
    id: "biz-tienda-3",
    name: "Supermercado MerqueFácil",
    category: CategoryType.TIENDA,
    owner: "Carlos Lozano",
    phone: "3201122334",
    address: "Avenida Principal #15-50",
    pointsRate: 1,
    description: "Precios de distribuidor en víveres, lácteos y carnes frías."
  },
  {
    id: "biz-tienda-4",
    name: "Estanquillo El Tambo",
    category: CategoryType.TIENDA,
    owner: "Jairo Montoya",
    phone: "3118901234",
    address: "Carrera 5 #5-12",
    pointsRate: 1,
    description: "Bebidas frías, abarrotes básicos, snacks y licores para tus celebraciones."
  },
  {
    id: "biz-tienda-5",
    name: "Variedades Las Américas",
    category: CategoryType.TIENDA,
    owner: "Blanca Inés Pinzón",
    phone: "3145678012",
    address: "Calle 9 #6-30",
    pointsRate: 1,
    description: "Papelería, útiles de aseo, víveres y heladería familiar."
  },

  // Productores Agrícolas
  {
    id: "biz-prod-1",
    name: "Asociación Finca El Mirador",
    category: CategoryType.PRODUCTOR,
    owner: "Humberto Urrego",
    phone: "3134567111",
    address: "Vereda La Esmeralda, km 2 vía la Escuela",
    pointsRate: 1.5, // 1.5x points to encourage direct farmer purchases!
    description: "Café especial suave, plátano verde, yuca y naranjas recolectadas hoy mismo.",
    featured: true
  },
  {
    id: "biz-prod-2",
    name: "Finca Villa María - Huevos del Campo",
    category: CategoryType.PRODUCTOR,
    owner: "Sandra Milena Rojas",
    phone: "3182345678",
    address: "Vereda El Limón",
    pointsRate: 1.5,
    description: "Huevos de gallina feliz campesina alimentada con maíz, 100% orgánicos."
  },
  {
    id: "biz-prod-3",
    name: "Cultivos Hidropónicos El Portal",
    category: CategoryType.PRODUCTOR,
    owner: "Ramiro Cardona",
    phone: "3103456789",
    address: "Vereda Guayabal",
    pointsRate: 1.5,
    description: "Lechugas, tomates chonto, pimentón y cilantro fresco de invernadero."
  },
  {
    id: "biz-prod-4",
    name: "Miel Silvestre Doña Rosa",
    category: CategoryType.PRODUCTOR,
    owner: "Rosa Delia Martínez",
    phone: "3167891234",
    address: "Sector El Bosque, Vereda La Laguna",
    pointsRate: 1.5,
    description: "Miel de abejas pura de bosque nativo, polen y propóleos naturales."
  },
  {
    id: "biz-prod-5",
    name: "Hortalizas y Frutales El Cedro",
    category: CategoryType.PRODUCTOR,
    owner: "Gonzalo Restrepo",
    phone: "3176543210",
    address: "Vereda Alto Redondo",
    pointsRate: 1.5,
    description: "Mora de castilla, gulupa, maracuyá y hortalizas de clima frío."
  },

  // Droguerías
  {
    id: "biz-drog-1",
    name: "Droguería San Jorge",
    category: CategoryType.DROGUERIA,
    owner: "Dra. Martha Luz Patiño",
    phone: "3127654321",
    address: "Calle Real #5-10, Al lado de la Estación",
    pointsRate: 1,
    description: "Fórmulas médicas, inyectología, toma de presión, pañales y perfumería.",
    featured: true
  },
  {
    id: "biz-drog-2",
    name: "FarmaPueblo Descuentos",
    category: CategoryType.DROGUERIA,
    owner: "Rigoberto Vélez",
    phone: "3104321098",
    address: "Carrera 7 #10-14",
    pointsRate: 1,
    description: "Gran surtido en medicamentos genéricos y de marca con los mejores precios."
  },
  {
    id: "biz-drog-3",
    name: "Droguería El Amparo",
    category: CategoryType.DROGUERIA,
    owner: "Marina Quintero",
    phone: "3119087654",
    address: "Esquina del Hospital Civil",
    pointsRate: 1,
    description: "Atención 24 horas para urgencias, leches de fórmula y cuidado materno."
  },

  // Carnicerías
  {
    id: "biz-carn-1",
    name: "Carnicería El Choto de Oro",
    category: CategoryType.CARNICERIA,
    owner: "Don Efraín Velásquez",
    phone: "3144455667",
    address: "Plaza de Mercado, Local 3 y 4",
    pointsRate: 1,
    description: "Carne selectionada de res, cerdo, ternera, embutidos artesanales y chorizos caseros.",
    featured: true
  },
  {
    id: "biz-carn-2",
    name: "Expendio de Carnes La Estancia",
    category: CategoryType.CARNICERIA,
    owner: "Fidel Antonio Ruíz",
    phone: "3139871234",
    address: "Calle 10 #5-44",
    pointsRate: 1,
    description: "Cortes madurados, carne molida en el acto y costilla especial de cerdo."
  },
  {
    id: "biz-carn-3",
    name: "Carnes y Pollo San José",
    category: CategoryType.CARNICERIA,
    owner: "Jesús Alberto Marín",
    phone: "3209876541",
    address: "Carrera 6 #8-50",
    pointsRate: 1,
    description: "Pollo de campo fresco, filetes de pechuga y asados para el fin de semana."
  },

  // Talleres Motos y Carros
  {
    id: "biz-moto-1",
    name: "Taller Hermanos Vargas (Motos)",
    category: CategoryType.TALLER_MOTO,
    owner: "Wilmer y Javier Vargas",
    phone: "3116543110",
    address: "Salida Vía Principal, entrada al pueblo",
    pointsRate: 1,
    description: "Repuestos certificados, sincronización, cambio de aceite y soldadura en general.",
    featured: true
  },
  {
    id: "biz-moto-2",
    name: "MotoServicios Ruedas Libres",
    category: CategoryType.TALLER_MOTO,
    owner: "Andrés 'El Mono' Herrera",
    phone: "3154321098",
    address: "Calle 7 #3-12",
    pointsRate: 1,
    description: "Mantenimiento preventivo, llantas nuevas y parches rápidos para pinchazos."
  },
  {
    id: "biz-carro-1",
    name: "Mecánica El Chasis - Automotriz",
    category: CategoryType.TALLER_CARRO,
    owner: "Inge. Nelson Duarte",
    phone: "3128909871",
    address: "Carrera 4 #2-40 (Sector Talleres)",
    pointsRate: 1,
    description: "Alineación y balanceo, mecánica de motor, escáner electrónico computarizado."
  },
  {
    id: "biz-carro-2",
    name: "AutoLavado y Lubricentro El Puente",
    category: CategoryType.TALLER_CARRO,
    owner: "Jaime Soto",
    phone: "3214560987",
    address: "Calle 12 junto al Río",
    pointsRate: 1,
    description: "Lavado detallado externo, aspirado de cojinería, cambio de filtros y aceites premium."
  },

  // Transporte
  {
    id: "biz-trans-1",
    name: "Acarreos y Mudanzas El Cacique",
    category: CategoryType.TRANSPORTE,
    owner: "Mauricio Benítez",
    phone: "3145612345",
    address: "Calle Real Sector Las Palmas",
    pointsRate: 1,
    description: "Camión turbo disponible para acarreos de cosechas, mudanzas locales y viajes nacionales."
  },
  {
    id: "biz-trans-2",
    name: "Mototaxis Colectivos El Pueblo",
    category: CategoryType.TRANSPORTE,
    owner: "Gremio Organizado",
    phone: "3198765432",
    address: "Bahía de transportes de la Plaza",
    pointsRate: 1,
    description: "Viajes rápidos puerta a puerta del pueblo a las veredas y puntos cercanos."
  },

  // Electricistas
  {
    id: "biz-elec-1",
    name: "Daniel Silva - Electricista Profesional",
    category: CategoryType.ELECTRICISTA,
    owner: "Daniel Silva",
    phone: "3105554321",
    address: "Trabajos a domicilio",
    pointsRate: 1.2,
    description: "Certificado CONTE. Acometidas de energía, cortocircuitos, planos eléctricos e iluminación."
  },
  {
    id: "biz-elec-2",
    name: "Instalaciones Eléctricas Gómez",
    category: CategoryType.ELECTRICISTA,
    owner: "Luis Fernando Gómez",
    phone: "3139081234",
    address: "Barrio Cooperativo",
    pointsRate: 1.2,
    description: "Mantenimiento residencial, instalación de duchas eléctricas, motobombas y redes."
  },

  // Estética
  {
    id: "biz-est-1",
    name: "Peluquería y Barbería El Estilo de Carlos",
    category: CategoryType.ESTETICA,
    owner: "Carlos Restrepo",
    phone: "3154567812",
    address: "Calle 6 #4-80",
    pointsRate: 1,
    description: "Cortes modernos caballeros, barba, peinados damas, tinturas y manicure.",
    featured: true
  },
  {
    id: "biz-est-2",
    name: "Spa y Salón de Belleza Oasis de Paz",
    category: CategoryType.ESTETICA,
    owner: "Lucero Blandón",
    phone: "3118907654",
    address: "Carrera 9 #11-50",
    pointsRate: 1,
    description: "Masajes relajantes, mascarillas faciales, depilación con cera e hidratación capilar."
  },

  // Panadería / Cafetería
  {
    id: "biz-pan-1",
    name: "Panadería El Trigo de Oro",
    category: CategoryType.PANADERIA,
    owner: "Gustavo Córdoba",
    phone: "3167778899",
    address: "Carrera 5 Esquina de la Escuela",
    pointsRate: 1,
    description: "Pan de bono caliente, buñuelos crujientes, bizcochos, café y tortas de cumpleaños.",
    featured: true
  },
  {
    id: "biz-pan-2",
    name: "Cafetería y Repostería Villa Café",
    category: CategoryType.PANADERIA,
    owner: "Adriana Montes",
    phone: "3204328901",
    address: "Calle Real #6-65",
    pointsRate: 1,
    description: "Café de origen preparado en diferentes métodos, postres caseros, jugos y salpicones."
  }
];

export const SEED_USERS: User[] = [
  {
    code: "JUAN01",
    name: "Juan Pérez García",
    phone: "3103456789",
    points: 125,
    totalEarned: 350,
    active: true
  },
  {
    code: "MARIA02",
    name: "María Constanza Rojas",
    phone: "3156789123",
    points: 480,
    totalEarned: 780,
    active: true
  },
  {
    code: "PEDRO03",
    name: "Pedro Julio Alarcón",
    phone: "3208765432",
    points: 90,
    totalEarned: 240,
    active: true
  },
  {
    code: "ADMIN",
    name: "Administrador MerquePuntos",
    phone: "3001234567",
    points: 0,
    totalEarned: 0,
    isAdmin: true,
    active: true
  }
];

export const SEED_PRIZES: Prize[] = [
  {
    id: "prize-1",
    title: "Bono de Compra $10.000 COP",
    pointsCost: 100,
    description: "Reclamable en cualquier Autoservicio o Tienda afiliada para compras generales.",
    stock: 50
  },
  {
    id: "prize-2",
    title: "Bono de Compra $25.000 COP",
    pointsCost: 220,
    description: "Excelente para mercar víveres o comprar carnes frescas en los expendios aliados.",
    stock: 25
  },
  {
    id: "prize-3",
    title: "Mercadito Campesino Express",
    pointsCost: 350,
    description: "Una canastilla repleta de verduras, plátano, yuca, huevos campesinos y pan fresco de las veredas.",
    stock: 12
  },
  {
    id: "prize-4",
    title: "Bono Recarga de Moto / Taller $40.000 COP",
    pointsCost: 500,
    description: "Válido para repuestos, cambio de aceite o reparaciones en los talleres de motos aliados.",
    stock: 10
  },
  {
    id: "prize-5",
    title: "Súper Mercada Familiar $100.000 COP",
    pointsCost: 1000,
    description: "El premio mayor. Una completa provisión de granos, víveres, aseo y aceites de primera necesidad.",
    stock: 5
  }
];
